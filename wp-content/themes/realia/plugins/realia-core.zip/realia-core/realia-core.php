<?php

/*
Plugin Name: Realia Core
Version: 1.0.1
Description: Realia core files.
Author: Aviators
Author URI: http://byaviators.com
*/

require_once 'custom-post-types/agencies.php';
require_once 'custom-post-types/agents.php';
require_once 'custom-post-types/faq.php';
require_once 'custom-post-types/landlords.php';
require_once 'custom-post-types/partners.php';
require_once 'custom-post-types/pricing.php';
require_once 'custom-post-types/properties.php';
require_once 'custom-post-types/submission.php';